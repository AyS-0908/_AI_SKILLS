# Phase 2 — ANALYZE

**PURPOSE:** Perform judgment analysis on candidates detected by the script and full artifact inspection.

---

## 1. TURNS

```
1 LLM turn
```

---

## 2. INPUTS

**IMPORTANT:** The full specification is NOT reloaded.

The specification may only be accessed for:
- verbatim quote extraction when a required quote is absent from an artifact
- runtime sections required by execution-model validation
- source verification for artifact rows explicitly marked as incomplete, uncertain, or source-missing

Contradiction analysis MUST rely first on verbatim quote fields already stored in the artifacts.
If a contradiction cannot be supported by artifact evidence or verified source text → MUST NOT be reported.

| Source              | Content                |
|---------------------|------------------------|
| compiled_audit.json | primary analysis input |
| segments.json       | section metadata       |
| contracts.json      | callable details       |
| tokens.json         | terminology groups     |

---

## 3. ARTIFACT STRUCTURE IMPACT REVIEW

**BEFORE STARTING MAIN ANALYSIS:**
Review `compiled_audit.json.artifact_structure_candidates[]` as mechanical extraction-reliability signals.

For each candidate, determine whether it:
- is a minor extraction warning with limited analytical effect
- weakens contradiction analysis
- weakens execution-model validation
- blocks reliable interpretation for a specific claim or section

**Reporting rules:**
- Record as issue type `ARTIFACT_STRUCTURE_ERROR`
- Classify under `EXTRACTION_WARNINGS`
- DO NOT treat as contradictions by default
- DO NOT let the script decide severity or analytical consequence

**Severity:** HIGH if structure error invalidates analysis for affected section; otherwise MEDIUM.

Create a dedicated `EXTRACTION_WARNINGS` section when one or more candidates materially affect audit reliability.

---

## 4. ARTIFACT-FIRST ANALYSIS RULE

Phase 2 MUST perform reasoning using artifact files as the primary evidence layer:
- compiled_audit.json (conflict_candidates, artifact_structure_candidates)
- segments.json
- contracts.json
- tokens.json

---

## 5. PRIORITY-SECTION RULE

Sections with `priority = true` in segments.json MUST be analyzed first.
For those sections: prefer depth over breadth. Do NOT suppress supported findings for token discipline.

---

## 6. SECTION A — CONTRADICTION ANALYSIS

### Primary Strategy
Candidate-first: use `compiled_audit.json.conflict_candidates[]` as the default investigation set.

### Secondary Sweep (BOUNDED)
Allowed only for:
- sections listed in `compiled_audit.json.risk_hotspots[]`
- sections where `priority = true`
- artifacts explicitly marked incomplete, uncertain, or source-missing

The auditor MUST NOT perform an unbounded full-artifact contradiction sweep.

### Required Coverage
- duplicate callable names with different signatures
- same callable used with incompatible expectations
- broken or dangling references
- return contract violations
- token collisions or semantic ambiguity supported by artifact evidence
- cross-index inconsistencies between callable contracts, token groups, and references

### Q1/Q2/Q3 Test (ALL contradictions MUST pass)

| Test | Meaning |
|------|---------|
| Q1   | Do A and B apply to the SAME operation or entity? |
| Q2   | Do A and B apply in the SAME execution context, scope, or trigger? If unspecified/ambiguous: do NOT auto-resolve as YES for Tier 1 — classify as Tier 2 ambiguity unless source verification proves same context |
| Q3   | Is it logically impossible for both A and B to be true simultaneously? |

**Reporting rule:** Report only if Q1=YES, Q2=YES, Q3=YES. If any NO → do not report.

### Mandatory Evidence Rule
Every contradiction MUST include: Quote A (verbatim) + Quote B (verbatim).
If both sides cannot be supported → MUST NOT be reported.

### Classification

| Tier   | Meaning                    |
|--------|----------------------------|
| Tier 1 | Reproducible contradiction |
| Tier 2 | Potential ambiguity        |

Tier 1 requires same quoted evidence → same finding on rerun.
Tier 2 allows interpretation variance.

### OUTPUT
`CONTRADICTIONS_TABLE`

---

## 7. SECTION B — EXECUTION MODEL & RUNTIME FAILURE VALIDATION

### Step 1 — Load Runtime Reasoning Context
Load only segments required for runtime analysis:
- Runtime Execution & UI Flows
- Foundational Rules / Laws
- Persistence & Storage and DB
- All sections where `priority = true`

If a category is not present in segments.json → mark `NOT PRESENT`.

### Step 2 — Extract Execution Model Axioms
From loaded segments, extract axioms explicitly stated in the specification.

**Minimum axiom set when available:**
- what triggers execution or rerun
- what state persists across executions
- when user input values are captured
- what causes state loss or reset

**Rules:**
- If no execution model explicitly described → create a spec-quality finding for missing execution model. Use `ASSUMED: Standard Sequential Execution` as temporary baseline.
- If multiple execution models described → test each independently.
- Any simulated scenario contradicting extracted axioms → INVALID, discard.

### Step 3 — Simulate Only Valid Execution Flows
Simulate runtime behavior within loaded context and under extracted axioms.

Check whether:
- triggers can start the expected execution
- required state is available when later steps depend on it
- user inputs are captured at the correct moment
- reset/rerun destroys data or breaks intended flow
- persistence logic and runtime flow remain compatible

### Step 4 — Detect Execution Failures
Record a failure only when the specification implies expected runtime behavior cannot succeed, can become inconsistent, or can lose required state.

Each reported execution failure MUST cite:
- at least one execution-axiom quote
- at least one runtime/persistence/specification quote

### Execution Reporting Guardrails
- If failure depends entirely on framework behavior (not spec-controlled) → DO NOT report
- If same root cause already in CONTRADICTIONS_TABLE → DO NOT duplicate
- If loaded materials contain no ordering/timing/lifecycle/persistence evidence → output: `INSUFFICIENT EVIDENCE FOR EXECUTION FAILURE VALIDATION`

### OUTPUT
- `EXECUTION_MODEL_AXIOMS`
- `EXECUTION_FAILURE_TABLE`

---

## 8. SECTION C — SPECIFICATION QUALITY CHECK

**PURPOSE:** Detect only high-signal spec-quality gaps that materially affect reliable implementation, validation, or safe operation.

### Primary Baseline
- AUDIT_FRAME
- segments.json
- contracts.json
- EXECUTION_MODEL_AXIOMS
- verified contradiction/execution evidence from Phase 2

### Token-Discipline Rules
- Targeted, not exhaustive
- Evaluate only concrete, source-grounded, high-impact gaps
- No broad best-practices review or style critique
- Prefer one finding per root cause
- Reuse already-loaded artifacts before reading additional source

### Mandatory Checks
1. Goal / scope mismatch visible from AUDIT_FRAME
2. Missing implementation-critical inputs, outputs, states, or acceptance criteria
3. Missing or non-measurable testability conditions
4. Missing error behavior when failure handling is required by the stated flow
5. Maintainability or coupling risks only when creating concrete execution/validation/change-risk consequence

These may produce Tier 1 (blocks implementation) or Tier 2 (advisory) findings.

### Testability Check
Flag when:
- acceptance criteria absent for critical flows
- expected outputs not measurable
- error behavior for critical flows unspecified
- completion cannot be objectively verified

### Reporting Rule
Do NOT report the same gap separately under multiple categories.
