---
name: audit-it
description: >
  Multi-pass Audit of TECHNICAL user input, e.g. PRD, Specification, or Code.
  Trigger this skill whenever the user request to audit, review, or check
  "consistency", "inconsistencies", "issues", "gaps", "ambiguities" or similar.
  Supports Markdown files, docx, pdf, and pasted text.
---

# YOUR ROLE

Static Specification Auditor for digital product.
3-Phase pipeline: Extract → Compile (script) → Analyze → Report.

---

# ARCHITECTURE

```
INPUT SPEC
     │
     ▼
Phase 1 — EXTRACT (1–2 LLM turns)
     │  writes JSON artifacts to /home/claude/audit_artifacts/
     ▼
Script — compile_artifacts.py (no LLM)
     │  writes compiled_audit.json
     ▼
Phase 2 — ANALYZE (1 LLM turn)
     │
     ▼
Phase 3 — REPORT (1 LLM turn)
     │
     ▼
FINAL_AUDIT_REPORT + audit_fixes.json
```

**Token strategy:** Full spec is in context only during Phase 1. Phases 2–3 work from extracted artifacts + targeted spec segments only.

---

# CORE RULES (enforced in all phases)

## Rule 1 — Evidence and Missing Information
- If required info is absent → report as finding. MUST NOT silently fill gaps.
- Any assumption for reasoning must be labeled `ASSUMED`.

## Rule 2 — Fact / Inference / Assumption Separation
Each finding MUST distinguish:
- FACT: supported by verbatim artifact or source quote
- INFERENCE: logical conclusion from facts
- ASSUMPTION: missing info temporarily assumed

A finding MUST NOT be Tier 1 if its core conclusion depends on an unstated, unverified assumption.

## Rule 3 — Tiering and Contradictions
- Each finding: `Tier 1` or `Tier 2`
- All contradiction findings MUST pass Q1/Q2/Q3 test

## Rule 4 — Reproducibility
- Tier 1: reproducible from same quoted evidence
- If reproducibility depends on interpretation → Tier 2

## Rule 5 — Phase Boundary and Efficiency
- Single-run 3-phase pipeline
- Each phase may access only its declared inputs
- MUST NOT speculatively reload the full specification
- If required inputs missing → output `INSUFFICIENT INPUTS` and STOP
- If a prior artifact is internally inconsistent → record it, continue if parseable, route via `artifact_structure_candidates[]` or `parsing_warnings[]`
- Re-derive only when inconsistency prevents reliable use of declared phase inputs

## Rule 6 — Evidence Hard Gate
- Use only inputs explicitly declared for current phase
- No quote = no finding
- Ambiguous but relevant evidence → mark `UNCERTAIN`
- Do not rely on prior chat context unless declared as phase input

## Rule 7 — Scope-Proportional Judgment
- Prioritize correctness, execution reliability, testability
- MUST NOT recommend architectural sophistication unless required to fix a concrete risk
- Evaluate against intended scope and maturity level from AUDIT_FRAME
- Distinguish: blocking gaps vs. ambiguities vs. optional improvements

## Rule 8 — Finding Finality by Phase
- Findings MUST NOT be silently suppressed mid-phase
- May only be: filtered by Design Intent Filter (Phase 3), merged during deduplication, escalated when fix verification fails

---

# PHASE ORCHESTRATION

## Phase 1 — EXTRACT
- **When:** Start of audit, full spec in context
- **Turns:** 1 turn if spec < 60k chars, 2 turns if ≥ 60k chars
- **Produces:** `segments.json`, `contracts.json`, `tokens.json` in `/home/claude/audit_artifacts/`
- **Conversation output:** Summary only (~500 tokens)
- **Reference:** Read `references/phase-extract.md` for full instructions

## Script — COMPILE
- **When:** Immediately after Phase 1 completes
- **Run:** `python3 scripts/compile_artifacts.py`
- **Input:** `/home/claude/audit_artifacts/{segments,contracts,tokens}.json`
- **Output:** `/home/claude/audit_artifacts/compiled_audit.json`
- **No LLM involvement.** Script performs mechanical checks only.

## Phase 2 — ANALYZE
- **When:** After script completes
- **Turns:** 1 LLM turn
- **Inputs:** compiled_audit.json + all Phase 1 artifacts + targeted spec segments
- **Full spec is NOT reloaded**
- **Produces:** CONTRADICTIONS_TABLE, EXECUTION_MODEL_AXIOMS, EXECUTION_FAILURE_TABLE, spec quality findings
- **Reference:** Read `references/phase-analyze.md` for full instructions

## Phase 3 — REPORT
- **When:** After Phase 2 completes
- **Turns:** 1 LLM turn
- **Produces:** FINAL_AUDIT_REPORT + `audit_fixes.json`
- **Reference:** Read `references/phase-report.md` for full instructions

---

# ARTIFACT SCHEMAS (summary)

All artifacts are JSON files in `/home/claude/audit_artifacts/`.

| File | Content | Written by |
|---|---|---|
| segments.json | Section map, categories, priority tags, AUDIT_FRAME | Phase 1 |
| contracts.json | Callable signatures, consumption sites, cross-refs | Phase 1 |
| tokens.json | Concept groups, variants, locations | Phase 1 |
| compiled_audit.json | Conflict candidates, structure candidates, risk hotspots | Script |
| FINAL_AUDIT_REPORT.md | Human + AI readable findings, fixes, status | Phase 3 |
| audit_fixes.json | Tier 1 atomic fixes for downstream AI-coder | Phase 3 |

Schema details are in the phase reference files.

---

# FINAL DIRECTIVE

Execute phases in strict order: Phase 1 → Script → Phase 2 → Phase 3.
Read the appropriate `references/phase-*.md` file before executing each phase.
