#!/usr/bin/env python3
"""
compile_artifacts.py — Mechanical validation of Phase 1 extraction artifacts.

PURPOSE:
  Perform deterministic checks on segments.json, contracts.json, tokens.json.
  Produce compiled_audit.json as a priority index for Phase 2.

DESIGN RULES:
  - Never parses the original specification
  - Only parses structured JSON artifacts from Phase 1
  - Does NOT assess product-goal alignment, completeness, testability, or design intent
  - Does NOT decide analytical impact, contradiction validity, or report severity
  - Each operation is independent; one failure does not abort the rest

INPUT:  /home/claude/audit_artifacts/{segments,contracts,tokens}.json
OUTPUT: /home/claude/audit_artifacts/compiled_audit.json
"""

import json
import os
import sys
from collections import defaultdict

ARTIFACT_DIR = "/home/claude/audit_artifacts"

def load_json(filename):
    """Load a JSON file, return (data, error_message)."""
    path = os.path.join(ARTIFACT_DIR, filename)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, f"File not found: {path}"
    except json.JSONDecodeError as e:
        return None, f"JSON parse error in {filename}: {e}"
    except Exception as e:
        return None, f"Error loading {filename}: {e}"


def safe_get(obj, *keys, default=None):
    """Safely traverse nested dicts/lists."""
    current = obj
    for k in keys:
        if isinstance(current, dict):
            current = current.get(k, default)
        elif isinstance(current, list) and isinstance(k, int) and 0 <= k < len(current):
            current = current[k]
        else:
            return default
        if current is None:
            return default
    return current


def step1_duplicate_functions(contracts):
    """Detect same function name with different signatures."""
    candidates = []
    if not contracts:
        return candidates
    
    entries = safe_get(contracts, "contracts", default=[])
    by_name = defaultdict(list)
    for entry in entries:
        name = safe_get(entry, "name", default="")
        sig = safe_get(entry, "signature", default="")
        declared_in = safe_get(entry, "declared_in", default="")
        if name:
            by_name[name].append({"signature": sig, "declared_in": declared_in})
    
    for name, occurrences in by_name.items():
        sigs = set(o["signature"] for o in occurrences)
        if len(sigs) > 1:
            candidates.append({
                "check_type": "DUPLICATE_FUNCTION",
                "entity": name,
                "details": [
                    {"signature": o["signature"], "location": o["declared_in"]}
                    for o in occurrences
                ],
                "message": f"Function '{name}' has {len(sigs)} different signatures"
            })
    return candidates


def step2_dangling_references(contracts, segments):
    """Detect reference targets that don't resolve to any segment."""
    candidates = []
    if not contracts or not segments:
        return candidates
    
    # Build set of known section IDs
    known_ids = set()
    for seg in safe_get(segments, "segments", default=[]):
        sid = safe_get(seg, "section_id", default="")
        if sid:
            known_ids.add(sid)
    
    refs = safe_get(contracts, "section_references", default=[])
    for ref in refs:
        target = safe_get(ref, "target_section", default="")
        source = safe_get(ref, "source_location", default="")
        if target and target not in known_ids:
            candidates.append({
                "check_type": "DANGLING_REFERENCE",
                "entity": target,
                "source_location": source,
                "reference_text": safe_get(ref, "reference_text_quote", default=""),
                "message": f"Reference to '{target}' from '{source}' does not resolve to any segment"
            })
    return candidates


def step3_return_type_mismatch(contracts):
    """Compare declared return type vs consumer expected type (string comparison).
    
    NOTE: This is a mechanical string-comparison check. On natural-language PRDs,
    it will over-flag (e.g. "company row" vs "id_company, company_name").
    This is by design: the script produces CANDIDATES for Phase 2 judgment.
    Skips entries where expected_type_quote is empty or UNSPECIFIED.
    """
    candidates = []
    if not contracts:
        return candidates
    
    entries = safe_get(contracts, "contracts", default=[])
    for entry in entries:
        name = safe_get(entry, "name", default="")
        declared_return = safe_get(entry, "declared_return", default="")
        if not declared_return or declared_return == "UNSPECIFIED":
            continue
        
        for site in safe_get(entry, "consumption_sites", default=[]):
            expected = safe_get(site, "expected_type_quote", default="")
            location = safe_get(site, "location", default="")
            if not expected or expected == "UNSPECIFIED":
                continue
            if declared_return.lower().strip() != expected.lower().strip():
                candidates.append({
                    "check_type": "RETURN_TYPE_MISMATCH",
                    "entity": name,
                    "declared_return": declared_return,
                    "expected_type": expected,
                    "declaration_location": safe_get(entry, "declared_in", default=""),
                    "consumer_location": location,
                    "message": f"'{name}' declares return '{declared_return}' but consumer at '{location}' expects '{expected}'"
                })
    return candidates


def step4_token_collisions(tokens):
    """Identify concept groups with collision risk (3+ entries AND 2+ distinct values)."""
    candidates = []
    if not tokens:
        return candidates
    
    groups = safe_get(tokens, "concept_groups", default=[])
    for group in groups:
        variants = safe_get(group, "variants", default=[])
        distinct_values = set(safe_get(v, "value", default="").lower().strip() for v in variants)
        if len(variants) >= 3 and len(distinct_values) >= 2:
            candidates.append({
                "check_type": "TOKEN_COLLISION",
                "entity": safe_get(group, "provisional_label", default="unknown"),
                "variant_count": len(variants),
                "variants": [
                    {"value": safe_get(v, "value", default=""), "location": safe_get(v, "location", default="")}
                    for v in variants
                ],
                "uncertainty": safe_get(group, "uncertainty_flag", default=False),
                "message": f"Concept group '{safe_get(group, 'provisional_label', default='unknown')}' has {len(variants)} entries with {len(distinct_values)} distinct values"
            })
    return candidates


def step5_orphan_functions(contracts):
    """Identify functions declared but never consumed."""
    candidates = []
    if not contracts:
        return candidates
    
    entries = safe_get(contracts, "contracts", default=[])
    for entry in entries:
        name = safe_get(entry, "name", default="")
        sites = safe_get(entry, "consumption_sites", default=[])
        if not sites:
            candidates.append({
                "check_type": "ORPHAN_FUNCTION",
                "entity": name,
                "declared_in": safe_get(entry, "declared_in", default=""),
                "message": f"Function '{name}' is declared but has no consumption sites"
            })
    return candidates


def step6_artifact_structure_checks(contracts, segments, tokens):
    """Detect deterministic cross-artifact integrity issues."""
    candidates = []
    
    # Build set of known section IDs
    known_ids = set()
    if segments:
        for seg in safe_get(segments, "segments", default=[]):
            sid = safe_get(seg, "section_id", default="")
            if sid:
                known_ids.add(sid)
    
    # 6a: Callable cannot link to a valid segment
    if contracts and segments:
        for entry in safe_get(contracts, "contracts", default=[]):
            declared_in = safe_get(entry, "declared_in", default="")
            if declared_in and declared_in not in known_ids:
                candidates.append({
                    "issue_type": "ARTIFACT_STRUCTURE_ERROR",
                    "check_type": "CALLABLE_SEGMENT_UNLINKED",
                    "referenced_entity": safe_get(entry, "name", default=""),
                    "source_artifact": "contracts.json",
                    "evidence_fields": {"declared_in": declared_in},
                    "message": f"Callable '{safe_get(entry, 'name', default='')}' declared in '{declared_in}' which is not a valid segment"
                })
    
    # 6b: section_references target not in segments (structure-level, distinct from Step 2 conflict candidates)
    if contracts and segments:
        for ref in safe_get(contracts, "section_references", default=[]):
            target = safe_get(ref, "target_section", default="")
            if target and target not in known_ids:
                candidates.append({
                    "issue_type": "ARTIFACT_STRUCTURE_ERROR",
                    "check_type": "REFERENCE_SEGMENT_UNLINKED",
                    "referenced_entity": target,
                    "source_artifact": "contracts.json",
                    "evidence_fields": {
                        "source_location": safe_get(ref, "source_location", default=""),
                        "target_section": target
                    },
                    "message": f"Section reference target '{target}' does not resolve to a valid segment"
                })
    
    # 6c: Token variant location not in segments
    if tokens and segments:
        for group in safe_get(tokens, "concept_groups", default=[]):
            for variant in safe_get(group, "variants", default=[]):
                loc = safe_get(variant, "location", default="")
                if loc and loc not in known_ids:
                    candidates.append({
                        "issue_type": "ARTIFACT_STRUCTURE_ERROR",
                        "check_type": "TOKEN_SEGMENT_UNLINKED",
                        "referenced_entity": safe_get(variant, "value", default=""),
                        "source_artifact": "tokens.json",
                        "evidence_fields": {
                            "variant_value": safe_get(variant, "value", default=""),
                            "location": loc,
                            "group": safe_get(group, "provisional_label", default="")
                        },
                        "message": f"Token variant '{safe_get(variant, 'value', default='')}' at '{loc}' does not resolve to a valid segment"
                    })
    return candidates


def step7_risk_density(contracts, segments):
    """Score sections by reference density × priority weight."""
    hotspots = []
    if not contracts or not segments:
        return hotspots
    
    # Build priority lookup
    priority_map = {}
    for seg in safe_get(segments, "segments", default=[]):
        sid = safe_get(seg, "section_id", default="")
        priority_map[sid] = safe_get(seg, "priority", default=False)
    
    # Count references per section
    incoming = defaultdict(int)
    outgoing = defaultdict(int)
    
    for ref in safe_get(contracts, "section_references", default=[]):
        src = safe_get(ref, "source_location", default="")
        tgt = safe_get(ref, "target_section", default="")
        if src:
            outgoing[src] += 1
        if tgt:
            incoming[tgt] += 1
    
    # Also count contract consumption as references
    for entry in safe_get(contracts, "contracts", default=[]):
        declared_in = safe_get(entry, "declared_in", default="")
        for site in safe_get(entry, "consumption_sites", default=[]):
            loc = safe_get(site, "location", default="")
            if declared_in:
                outgoing[declared_in] += 1
            if loc:
                incoming[loc] += 1
    
    # Score all known sections
    all_sections = set(list(incoming.keys()) + list(outgoing.keys()) + list(priority_map.keys()))
    scored = []
    for sid in all_sections:
        ref_count = incoming.get(sid, 0) + outgoing.get(sid, 0)
        priority_weight = 2 if priority_map.get(sid, False) else 1
        score = ref_count * priority_weight
        if score > 0:
            scored.append({
                "section_id": sid,
                "incoming_refs": incoming.get(sid, 0),
                "outgoing_refs": outgoing.get(sid, 0),
                "priority": priority_map.get(sid, False),
                "risk_score": score
            })
    
    scored.sort(key=lambda x: x["risk_score"], reverse=True)
    return scored[:20]  # top 20


def main():
    warnings = []
    output = {
        "conflict_candidates": [],
        "artifact_structure_candidates": [],
        "risk_hotspots": [],
        "artifact_stats": {},
        "parsing_warnings": []
    }
    
    # Load artifacts
    segments, seg_err = load_json("segments.json")
    contracts, con_err = load_json("contracts.json")
    tokens, tok_err = load_json("tokens.json")
    
    if seg_err:
        warnings.append(seg_err)
    if con_err:
        warnings.append(con_err)
    if tok_err:
        warnings.append(tok_err)
    
    # Abort only if ALL artifacts failed
    if not segments and not contracts and not tokens:
        output["parsing_warnings"] = warnings
        output["parsing_warnings"].append("FATAL: No artifacts could be loaded. Aborting compile.")
        write_output(output)
        return 1
    
    # Stats
    output["artifact_stats"] = {
        "segments": len(safe_get(segments, "segments", default=[])) if segments else 0,
        "contracts": len(safe_get(contracts, "contracts", default=[])) if contracts else 0,
        "concept_groups": len(safe_get(tokens, "concept_groups", default=[])) if tokens else 0,
        "section_references": len(safe_get(contracts, "section_references", default=[])) if contracts else 0
    }
    
    # Run each step independently
    conflict_candidates = []
    structure_candidates = []
    
    # Step 1: Duplicate functions
    try:
        conflict_candidates.extend(step1_duplicate_functions(contracts))
    except Exception as e:
        warnings.append(f"Step 1 (duplicate functions) failed: {e}")
    
    # Step 2: Dangling references → conflict candidates
    try:
        conflict_candidates.extend(step2_dangling_references(contracts, segments))
    except Exception as e:
        warnings.append(f"Step 2 (dangling references) failed: {e}")
    
    # Step 3: Return type mismatch
    try:
        conflict_candidates.extend(step3_return_type_mismatch(contracts))
    except Exception as e:
        warnings.append(f"Step 3 (return type mismatch) failed: {e}")
    
    # Step 4: Token collisions
    try:
        conflict_candidates.extend(step4_token_collisions(tokens))
    except Exception as e:
        warnings.append(f"Step 4 (token collisions) failed: {e}")
    
    # Step 5: Orphan functions
    try:
        conflict_candidates.extend(step5_orphan_functions(contracts))
    except Exception as e:
        warnings.append(f"Step 5 (orphan functions) failed: {e}")
    
    # Step 6: Artifact structure checks → structure candidates
    try:
        structure_candidates.extend(step6_artifact_structure_checks(contracts, segments, tokens))
    except Exception as e:
        warnings.append(f"Step 6 (artifact structure) failed: {e}")
    
    # Step 7: Risk density
    try:
        output["risk_hotspots"] = step7_risk_density(contracts, segments)
    except Exception as e:
        warnings.append(f"Step 7 (risk density) failed: {e}")
    
    output["conflict_candidates"] = conflict_candidates
    output["artifact_structure_candidates"] = structure_candidates
    output["parsing_warnings"] = warnings
    
    write_output(output)
    
    # Summary
    print(f"Compile complete:")
    print(f"  Conflict candidates: {len(conflict_candidates)}")
    print(f"  Structure candidates: {len(structure_candidates)}")
    print(f"  Risk hotspots: {len(output['risk_hotspots'])}")
    print(f"  Warnings: {len(warnings)}")
    print(f"  Output: {os.path.join(ARTIFACT_DIR, 'compiled_audit.json')}")
    return 0


def write_output(data):
    path = os.path.join(ARTIFACT_DIR, "compiled_audit.json")
    os.makedirs(ARTIFACT_DIR, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    sys.exit(main())
