# Phase 3 — REPORT

**PURPOSE:** Generate final audit report and structured fixes.

---

## 1. INPUTS

| Source              | Content                   |
|---------------------|---------------------------|
| Phase 2 findings    | contradictions + failures + spec quality |
| compiled_audit.json | artifact stats            |
| artifact JSONs      | quotes for fixes          |

---

## 2. REPORTING PIPELINE (MANDATORY)

### Step 1 — Tier Routing

Separate all incoming findings:
- **Tier 1** → full pipeline (Steps 2–7)
- **Tier 2** → Design Intent Filter + Severity Assignment only → route to ADVISORY_NOTES

### Step 2 — Design Intent Filter

For every finding, verify whether the flagged behavior is:
- explicitly excluded
- explicitly compensated through a linked safeguard
- explicitly justified via "Rationale:", "Design Intent:", or "Justification:" statement in the same section

If yes → remove from final findings → place in `ACCEPTED_BY_DESIGN`.

### Step 3 — Severity Assignment

| Source | Default Severity |
|---|---|
| Execution Failures, Tier 1 | CRITICAL |
| API-Level Conflict, Tier 1 | HIGH |
| Return Contract Violation, Tier 1 | HIGH |
| Integration Gap, Tier 1 | HIGH |
| Broken Reference, Tier 1 | MEDIUM |
| Token Collision, Tier 1 | MEDIUM |
| All Tier 2 findings | LOW |

Override default only with explicit justification.

### Step 4 — Confidence Assignment

| Value  | Meaning |
|--------|---------|
| HIGH   | directly supported by explicit artifact/source evidence, minimal interpretation |
| MEDIUM | supported by evidence, requires limited interpretation |
| LOW    | plausible concern, evidence partial/ambiguous/assumption-dependent |

Confidence MUST be reported in every final finding entry.

### Step 5 — Source Re-Verification

Any finding with incomplete, source-missing, or verification-flagged evidence MUST be checked against original specification text for the referenced section only.

- If verified → keep in final findings
- If not verified → move to `ESCALATED_TO_ARCHITECTURE` with rationale: "Source Verification Failed: Referenced text not found in Specification Chunks"

### Step 6 — Atomic Fix Generation (Tier 1 only)

**Requirements:**
- smallest edit surface possible
- exact target location
- operation = ADD / REMOVE / REPLACE
- exact target context
- exact fix content

Tier 2 findings MUST NOT receive atomic fixes.

**Token Collision Tie-Breaker:**
- prefer variant used in callable contracts
- otherwise prefer variant most consistently used across priority sections

### Step 7 — Fix Verification (Tier 1 only, MANDATORY)

For each atomic fix, before finalizing:
1. Extract fix text
2. Scan all verbatim quotes in Phase 1–2 artifacts tied to the same entity or section
3. Apply Q1/Q2/Q3 between fix text and each matching quote

**If conflict detected (Q1/Q2/Q3 = Y/Y/Y):**
- (a) Expand fix once to cover both locations, re-verify, OR
- (b) Escalate to `ESCALATED_TO_ARCHITECTURE` if expansion requires non-atomic change

Conflict checking MUST use existing artifact quotes only; do not invent hypothetical downstream conflicts.

**If no conflict → mark `VERIFIED`**

**Recursion limit:** If expanded fix fails verification again → ESCALATE. Max one expansion per finding.

**Priority-Section Regression Flag:**
- If a VERIFIED or EXPANDED fix modifies a `priority = true` section → mark `REQUIRES_REGRESSION_TEST`
- This flag does not invalidate the fix; it signals re-audit is advisable

Each Tier 1 finding MUST contain:
- `fix_status`: VERIFIED / EXPANDED / ESCALATED
- `regression_flag`: REQUIRES_REGRESSION_TEST or NONE

### Step 8 — Deduplication and Blocking Status

If same root cause appears multiple times → keep highest-severity instance only.

**Blocking status:**
- BLOCKING = any Tier 1 finding with severity CRITICAL or HIGH
- NON-BLOCKING = only Tier 1 MEDIUM/LOW remain
- CLEAN = zero Tier 1 findings

Tier 2 findings never affect blocking status.

---

## 3. OUTPUTS

### 3.1 FINAL_AUDIT_REPORT

Written to `/home/claude/audit_artifacts/FINAL_AUDIT_REPORT.md`.

Must contain:

**1. EXECUTIVE_STATUS**
- BLOCKING_STATUS: BLOCKING / NON-BLOCKING / CLEAN
- IMPLEMENTATION_READINESS: READY / READY WITH MINOR FIXES / NOT READY

**2. EXTRACTION_WARNINGS** (when artifact-structure candidates materially affect reliability)
- issue_type: ARTIFACT_STRUCTURE_ERROR
- visually separated from spec-level findings

**3. TIER_1_FINDINGS**
Structured findings with verified atomic fixes.

For every finding:
- id, location, category, tier, severity, confidence
- evidence_quote, issue, impact
- operation (ADD/REMOVE/REPLACE), exact_fix_text
- fix_status, regression_flag

**4. ADVISORY_NOTES**
Tier 2 findings, never blocking.

**5. ACCEPTED_BY_DESIGN**
Findings dismissed by Design Intent Filter.

**6. ESCALATED_TO_ARCHITECTURE**
Findings requiring non-atomic change or lacking source verification.

**7. RISK_HOTSPOTS**
Sections ranked by density / priority.

**Implementation readiness** must consider:
- remaining Tier 1 findings
- missing validation criteria
- unresolved architectural escalations
- extraction reliability

### 3.2 audit_fixes.json

Written to `/home/claude/audit_artifacts/audit_fixes.json`.

- Tier 1 findings only
- One entry per verified or expanded atomic fix
- Each entry: ref, tier, severity, location, operation, target_text or target_context, fix_text, status

**Consistency rule:** audit_fixes.json must match FINAL_AUDIT_REPORT. If mismatch → FINAL_AUDIT_REPORT prevails.

**Field definitions:**
- `fact` = observation supported by quoted evidence
- `inference` = diagnosis derived from the fact
- `impact` = execution, validation, or maintenance consequence
- `recommended_action` = concise correction intent
- `exact_fix_text` = atomic patch content (Tier 1 only)
