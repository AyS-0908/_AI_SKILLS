# Phase 1 — EXTRACT

**PURPOSE:** Extract structured artifacts from the specification while the full specification is still in context.

---

## 0. AUDIT FRAME

Extract the audit reference frame from the provided material. This becomes the baseline for all later findings.

**AUDIT_FRAME content:**
- audited artifact type
- product objective
- target user or audience
- explicit scope
- explicit non-goals / exclusions
- technical stack or execution environment
- key constraints
- success / acceptance criteria when present
- `missing_frame_items`: any required frame element not found in the source

If an element is missing: record in `missing_frame_items`. May produce a spec-quality finding in Phase 2.

AUDIT_FRAME extraction is part of Phase 1 — it MUST NOT create an additional phase or extra LLM turn.

---

## 1. PRIORITY TAGGING RULE

Priority tagging MUST be mechanical only.

**Rule 1:** Mark as priority if the section contains any of:
- state management or persistence logic
- concurrency or async operations
- cross-component dependencies
- user input handling or validation
- error handling or recovery flows
- timing-sensitive operations

**Rule 2:** Also mark as priority if section contains any of these strings (case-insensitive):
`async`, `await`, `persist`, `save`, `db`, `state`, `mutex`, `lock`, `validate`, `error`, `retry`, `timeout`, `callback`

**Rule 3:** Write the reason into `priority_reason`.

---

## 2. TURNS

| Spec Size   | Turns | Split Strategy            |
|-------------|-------|---------------------------|
| < 60k chars | 1     | All artifacts in one turn |
| ≥ 60k chars | 2     | Turn A: segments + tokens / Turn B: contracts |

---

## 3. EXTRACTION OUTPUTS

Directory: `/home/claude/audit_artifacts/`

### 3.1 segments.json

Section map of the specification.

**Constraints:**
- preserve original section grouping
- no summarization, reinterpretation, renaming, or renumbering
- if an expected category is absent → mark as `NOT_PRESENT`
- priority tagging must be mechanical with reason

```json
{
  "audit_frame": {
    "artifact_type": "PRD",
    "product_objective": "...",
    "target_user": "...",
    "scope": "...",
    "non_goals": ["..."],
    "tech_stack": "...",
    "constraints": ["..."],
    "acceptance_criteria": ["..."],
    "missing_frame_items": ["..."]
  },
  "segment_categories": {
    "Foundational Rules / Laws": ["§1.0", "§1.1"],
    "Single Sources of Truth (SSOTs)": ["§2.0"],
    "Interfaces & Contracts": ["§3.0"],
    "Runtime Execution & UI Flows": ["§4.0"],
    "Persistence & Storage and DB": ["§5.0"],
    "Output / Execution Artifacts": [],
    "NOT_PRESENT": ["API"]
  },
  "segments": [
    {
      "section_id": "§4.7",
      "title": "Execution Model",
      "line_start": 340,
      "line_end": 412,
      "category": "Runtime Execution & UI Flows",
      "priority": true,
      "priority_reason": "contains state management and persistence logic"
    }
  ]
}
```

### 3.2 contracts.json

Callable entities, declared contracts, consumption sites, and cross-reference map.

**Note:** The script compares `signature` fields; the LLM cites `exact_signature_quote` fields.

**CRITICAL — consumption_sites extraction rule:**
`consumption_sites` tracks where a function's RETURN VALUE is consumed or destructured — NOT where the function is invoked.
- `consumer_quote`: verbatim text showing how the return value is used (e.g., `"result = create_project(name)"`)
- `expected_type_quote`: the type/shape the consumer assumes for the return value (e.g., `"result.data"`)
- Do NOT record the function's input parameters as `expected_type_quote`
- If a step invokes the function but does not visibly consume its return value, do NOT add it as a consumption site

```json
{
  "contracts": [
    {
      "name": "create_project",
      "name_quote": "create_project",
      "signature": "create_project(name: str) -> UUID",
      "exact_signature_quote": "create_project(name: str) -> UUID",
      "declared_return": "UUID",
      "declared_return_quote": "-> UUID",
      "declared_in": "§3.1",
      "consumption_sites": [
        {
          "location": "§4.7",
          "consumer_quote": "project_id = create_project(name)",
          "expected_type_quote": "project_id"
        }
      ]
    }
  ],
  "section_references": [
    {
      "source_location": "§4.7",
      "reference_text_quote": "See Section 3.1",
      "target_section": "§3.1",
      "exists_in_provided_chunks": true
    }
  ]
}
```

### 3.3 tokens.json

Raw token groups for lexical consistency analysis.

**Constraints:**
- No canonical token may be chosen in Phase 1
- Group tokens ONLY when: explicitly defined as aliases in the spec, OR identical identifier names case-insensitively across sections
- Do NOT infer semantic equivalence
- If grouping confidence is uncertain → `uncertainty_flag = true`
- Do NOT create a concept group when the same identifier (same value, same casing) appears consistently across multiple sections — that is consistency evidence, not a collision candidate. Only group when 2+ DISTINCT variant values exist for what appears to be the same concept.
- Purpose of tokens.json is to surface NAMING INCONSISTENCIES. If every occurrence uses the same spelling → no group needed.

```json
{
  "concept_groups": [
    {
      "provisional_label": "project_id_family",
      "grouping_basis": "identical_identifier_case_insensitive",
      "uncertainty_flag": false,
      "variants": [
        {
          "value": "project_id",
          "variant_quote": "project_id",
          "location": "§2.4"
        },
        {
          "value": "projectId",
          "variant_quote": "projectId",
          "location": "§3.1"
        }
      ]
    }
  ]
}
```

---

## 4. VERBATIM TRACEABILITY REQUIREMENT

All Phase 1 artifacts MUST preserve enough verbatim evidence to support later contradiction analysis without globally reloading the specification.

**Minimum:**
- every callable entry: verbatim signature evidence
- every declared return: verbatim return quote
- every consumption site: verbatim usage quote
- every cross-reference: verbatim reference quote
- every token variant: verbatim token quote
- every uncertain grouping: explicitly marked

**If an extracted item cannot be tied to a verbatim quote:** It MUST NOT be used as contradiction evidence in Phase 2.

---

## 5. CONVERSATION OUTPUT

Only a summary appears in chat:

```
Extraction Summary:
  Segments: 24 (8 priority)
  Callable contracts: 30
  Concept groups: 15
  Ambiguous token groups: 4
  Section references: 18
```

Approximate size: ~500 tokens.

---

## 6. EXTRACTION INTEGRITY CHECK (MANDATORY)

Before concluding Phase 1:

### Step 1 — Segment Coverage
The union of all extracted segments MUST cover 100% of the specification.
If any section is unassigned → STOP → regenerate segments.json.

### Step 2 — Artifact Coverage
Verify all 3 artifacts were generated: segments.json, contracts.json, tokens.json.
If any missing → STOP → regenerate Phase 1.

### Step 3 — Suspicion Threshold
Rerun extraction if ANY of:
- segments < 5
- callable signatures = 0 AND segments.json contains sections categorized as "Interfaces & Contracts"
- token groups = 0 AND segments count > 10
- cross references = 0 while multiple sections reference other sections
