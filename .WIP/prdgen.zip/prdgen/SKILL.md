---
name: prdgen
description: >
  AI-powered PRD Generator wizard for non-technical users. Guides users
  step-by-step through building a complete Product Requirements Document
  and Execution Kit for AI-Coders (Cursor, Claude Projects, etc.).
  Trigger this skill whenever the user mentions: "generate a PRD",
  "create a PRD", "build a spec", "write requirements", "execution kit",
  "vibe coding setup", "AI coder instructions", "help me spec my project",
  "PRD generator", "product requirements", or any request to create
  structured project documentation for AI-assisted coding. Also trigger
  when user says "start a new project" or "I want to build [something]"
  and seems to need structured planning before coding.
---

# PRD Generator Skill

## Purpose

Guide a non-technical user through creating a complete **Execution Kit** for
an AI-Coder. The kit contains:

- **PRD_Master.md** — Project context, constraints, design DNA (immutable constitution)
- **PRD_Plan.md** — Features, workflows, data schema (mutable roadmap)
- **agent_architect.md** — Planning agent instructions
- **agent_builder.md** — Coding agent instructions
- **agent_reviewer.md** — Audit agent instructions
- **platform config** — .cursorrules or generic platform instructions
- **readme.md** — How-to for the user
- **.env.example** — API key placeholders

---

## How This Works

Claude acts as both the **form** and the **AI advisor**. Instead of filling
widgets in a webapp, the user has a conversation. Claude tracks all answers
in an internal JSON state object, offers AI suggestions, and at the end
generates the full Execution Kit as a downloadable ZIP.

---

## Step 0 — Initialize

When this skill triggers:

1. Read `references/sections_config.json` to load the section/field definitions.
2. Read `references/prd_quality_rules.md` for PRD quality criteria.
3. Initialize an empty state object in your working memory:

```
state = {
  "current_section": 0,
  "completed_sections": [],
  "fields": {}   // keyed by field.id → { value, origin: "user"|"ai" }
}
```

4. Greet the user and explain the process briefly:

> "I'll guide you through 7 sections to build a complete PRD and Execution
> Kit for your AI-Coder. For each section, I'll ask you questions and can
> suggest answers if you're unsure. At the end, I'll generate a ZIP with
> all the files you need. Let's start!"

5. Proceed to Section 1.

---

## Step 1 — Guided Section Walk-Through

Process sections **in order** (1→7). For each section:

### A. Present the Section

- State the section number, title, and purpose (from sections_config.json).
- List the fields the user needs to fill, with their labels and help text.
- For fields with `options`, show the choices.
- For fields with `default` values, mention them.

### B. Collect Answers

- Ask the user to provide their answers. Accept free-form responses.
- For **required** fields: don't move to the next section until filled.
- For **optional** fields: explicitly say "optional — skip if you want."
- Parse the user's response and map values to field IDs.
- Store each answer: `state.fields[field_id] = { value: X, origin: "user" }`.

### C. Offer AI Auto-Fill

After presenting a section, ALWAYS offer:

> "Would you like me to suggest answers for the remaining fields based on
> what you've told me so far? I can fill in what I think makes sense and
> you can edit anything."

If the user accepts:
- Use all previously collected state (especially `project_description`) as context.
- Generate sensible values for unfilled fields in the current section.
- Present suggestions clearly with the 🤖 prefix.
- Store accepted suggestions as `origin: "ai"`.
- The user can override any AI suggestion (override changes origin to "user").

### D. Confirm and Advance

Before moving to the next section:
- Summarize what was captured for the current section.
- Ask: "Ready to move to the next section, or want to change anything?"
- Mark section as completed in state.

### E. Adaptive Section Reframing

Some sections need reframing based on the project type. After Section 1 is
complete, check `project_type` and apply these rules:

**If project has NO visual UI** (project_type is "Automation / Workflow",
or the description clearly indicates a CLI tool, Skill, API-only service,
or similar non-UI project):

- **Section 4 (UX & Design)** → Reframe as **"Output & Document Formatting"**
  - `design_tone` → "Tone of the generated output (documents, reports, etc.)"
  - `design_dna` → "Formatting style (minimalist, dense, structured, etc.)"
  - `design_primary_color` → Offer to mark as "N/A"
  - `design_wireframe_desc` → "Document structure and layout standards"
  - Explain the reframing to the user before collecting answers.

- **Section 5 (Technical Architecture)** → Reframe labels:
  - `tech_stack_fe` → "User Interface / Runtime Environment"
  - `tech_stack_be` → "Core Runtime / Execution Environment"
  - `tech_stack_db` → "Data Storage / State Management"
  - Explain that the standard "frontend/backend/database" labels don't
    apply, and offer adapted descriptions.

**If project IS a standard webapp/mobile app**: No reframing needed.
Use all labels and fields as defined in sections_config.json.

---

## Step 2 — Section Definitions (Quick Reference)

The authoritative field definitions are in `references/sections_config.json`.
Here is the section flow for quick reference:

### Section 1: Project Context
Core identity — project name, type, audience, description, value prop, timeline.
**This section gates everything else.** Nothing proceeds until it's filled.

### Section 2: Product Definition
User model, success metrics, personas, pages/modules scope, out-of-scope.

### Section 3: Functional Requirements
Features & user stories, workflow logic, business rules, glossary, acceptance
criteria, edge cases.

### Section 4: UX & Design
Tone, design DNA, colors, references, wireframe description.

### Section 5: Technical Architecture
Frontend/backend/DB stack, data schema, constraints, API keys needed, NFRs.

### Section 6: AI Agents Strategy
Target platform, active agents, coding standards, custom rules, tool policy.

### Section 7: Review & Export
Preview the PRD, confirm approval, generate the Execution Kit.

---

## Step 3 — AI Advisor Mode

At ANY point during the walk-through, the user may ask questions like:
- "What should I choose for the database?"
- "Can you explain what NFRs are?"
- "Is this a good user story?"

When this happens:
- **Answer the question** using the full project context collected so far.
- Be pedagogical — explain the "why" for non-technical users.
- Offer **at least 2 options** when suggesting technical choices.
- After answering, return to where you left off in the wizard.
- NEVER modify state silently — always show what you're suggesting and get confirmation.

---

## Step 4 — Review & Export

When Section 7 is reached:

### A. PRD Preview

Generate a preview of the PRD_Master.md content using the collected state.
Show it to the user in a code block. Ask for any final edits.

### B. Generate Execution Kit

Once the user confirms:

1. Run `scripts/generate_kit.py` — this script:
   - Reads the state JSON (written to a temp file)
   - Loads `.tpl` template files from the `templates/` directory
   - Renders all templates with the collected field values
   - Selects the correct readme variant based on platform (Cursor vs Generic)
   - Validates output for unresolved variables
   - Packages everything into a ZIP
2. Present the ZIP file to the user for download.

```bash
# Write state to temp file, then generate
python3 /path/to/skill/scripts/generate_kit.py /tmp/prdgen_state.json /mnt/user-data/outputs/execution_kit.zip
```

3. Present the file and give a brief summary of what's inside.

---

## Critical Rules

### PRD Quality (from prd_quality_rules.md)
- No forward references — earlier sections constrain later ones
- No ambiguous phrases like "as defined later"
- No excessive nesting (max 3 heading levels)
- Lists are exhaustive unless stated otherwise
- Sections follow dependency order: Scope → SSOT → Laws → Modules → Flows → AI → UI → Export

### User Interaction Rules
- **User edits always win** over AI suggestions
- **Never write without explicit user action** — always show + confirm
- Explain technical terms when the user seems non-technical
- When uncertain, ask clarifying questions instead of guessing
- Label AI-generated content with 🤖 prefix
- Label uncertain claims as [Inference] or [Assumption]

### State Tracking
- Track every field's `origin` (user vs ai) — this matters for the output
- Required fields block progression — remind the user which ones are missing
- The `project_description` field is the **primary grounding** for all AI suggestions

---

## File References

| File | When to read | Purpose |
|------|-------------|---------|
| `references/sections_config.json` | Step 0 (always) | Field definitions, types, options, requirements |
| `references/prd_quality_rules.md` | Step 0 (always) | PRD validity criteria for review phase |
| `references/templates.md` | If editing templates | TOC & rules for the template system |
| `templates/*.tpl` | At export (read by script) | Actual template files — SSOT for output |
| `scripts/generate_kit.py` | Step 4 (export) | ZIP generation script |
