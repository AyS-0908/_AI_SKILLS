# PRD MASTER: {{ project_name }}

## 1. PROJECT OVERVIEW
- **Project Type:** {{ project_type }}
- **One-line Pitch:** {{ value_proposition }}
- **Timeline Goal:** {{ timeline }}

### Description
{{ project_description }}

---

## 2. PRODUCT DEFINITION
- **User Model:** {{ user_type }}
- **Success Metrics:** {{ success_criteria }}

### Target Personas
{{ user_personas }}

### Application Scope (Pages & Modules)
{{ application_scope }}

### Out of Scope
{{ out_of_scope }}

### Business Rules
{{ business_rules }}

### Glossary & Definitions
{{ glossary }}

---

## 3. UX & DESIGN SYSTEM
- **Tone of Voice:** {{ design_tone }}
- **Design DNA:** {{ design_dna }}
- **Primary Color:** {{ design_primary_color }}

### Design References
{{ design_references }}

### Layout & Wireframe
{{ design_wireframe_desc }}

---

## 4. TECHNICAL ARCHITECTURE
- **Frontend:** {{ tech_stack_fe }}
- **Backend/API:** {{ tech_stack_be }}
- **Database:** {{ tech_stack_db }}

### Data Schema
{{ data_schema }}

### Constraints & Compliance
{{ tech_constraints }}

### Non-Functional Requirements (NFR)
{{ nfr_security }}

---

## 5. TECHNICAL DNA & GUARDRAILS

### Coding Core Principles
{{ coding_standards }}

### Robustness & Edge Cases
{{ edge_cases }}

### Tooling & Execution Policy
{{ agent_tool_policy }}

### User-Specific Rules
{{ custom_agent_rules }}
