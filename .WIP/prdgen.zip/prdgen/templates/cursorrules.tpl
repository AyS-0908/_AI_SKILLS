# Cursor Rules for {{ project_name }}
Direct all architectural queries to `agent_architect.md`.
Direct all implementation tasks to `agent_builder.md`.
Direct all audits to `agent_reviewer.md`.
Always respect the `PRD_Master.md`.
