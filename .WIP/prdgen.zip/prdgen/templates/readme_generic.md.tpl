# Execution Kit: {{ project_name }}

## 🚀 Step 1: Setup

### Option A: AI-Coder (Cursor, VS Code + Roo Code, etc.)
1. Open this entire folder in your editor.
2. Rename `.env.example` to `.env` and fill in your API keys.
3. Ensure the AI has access to all `.md` files (especially `platform_generic.md`).

### Option B: Web Tools (Claude Projects, ChatGPT, Gemini)
1. Upload `PRD_Master.md` and `PRD_Plan.md` to "Project Knowledge" / "Files".
2. Paste agent instructions into 'System Prompt' when switching roles.

---

## ⚡ Step 2: First Prompt

> "I have provided the PRD_Master, PRD_Plan, and three Agent files. Please read `platform_generic.md` and confirm you are ready to begin as the **Architect** to review the PRD_Plan."

---

## 🛠 Step 3: Workflow
1. **Plan:** Ask the **Architect** to update `PRD_Plan.md` for the next feature.
2. **Build:** "Switch to **Builder** mode and implement the next task."
3. **Review:** "Switch to **Reviewer** mode and audit the code."

---

## ⚠️ Safety
- Review all commands before allowing `execute_command`.
- If the AI contradicts `PRD_Master.md`, the Master file always wins.
