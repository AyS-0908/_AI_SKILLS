# PRD Quality Rules

## Why This Matters

AI-Coders read PRDs top-to-bottom, mostly in one pass. They do NOT ask
clarifying questions, do NOT have common sense, and do NOT reorder sections.
The PRD structure directly drives their understanding.

## Structural Rules

1. **Section order = dependency order** — earlier sections constrain later ones.
2. **If conflict: earliest definition wins** — this is the authoritative rule.
3. **Headings = execution boundaries** — each heading starts a new scope.
4. **Lists are exhaustive** — unless explicitly stated otherwise.

## Section Order (Dependency Chain)

0. Scope — project intent, end-user, objective, solution, tech-stack
1. SSOT — data models, schemas, contracts (before any consuming logic)
2. Laws — invariants and non-negotiable rules
3. Module responsibilities — file boundaries and ownership
4. Flows — core runtime lifecycle
5. AI Augmentation — explicit AI read/write permissions
6. UI behavior — user-facing interactions
7. Terminal operations — export, packaging, delivery (one-way only)

## Invalidity Criteria

A generated PRD is **INVALID** if any of these are true:

- **Duplicate definition** — downstream sections redefine SSOT or Law elements
- **Forward reference** — earlier section relies on later-defined concepts
- **Rigid reference** — concepts referred to by section/paragraph number (fragile)
- **Scattered structure** — runtime behavior introduces new data structures
- **Ambiguity phrases** — "as defined later", "will be explained below"
- **AI before lifecycle** — AI behavior specified before core system lifecycle
- **Excessive nesting** — more than 3 heading levels (e.g., ##### 2.4.1.5)
- **Human prose** — too much narrative; PRD should be executable instructions

## Formatting Guidelines

### For Data Contracts (SSOT)
- Use tables when possible
- Normative, not narrative
- Exhaustive

### For Rules/Laws
- Execution Context → Rule → Implementation → Constraint → Logic → UI/UX → Failure Mode

### For Flows
- Sequential, strictly ordered steps
- Triggers → Objective → Execution Logic → UI/UX → Failure Modes

### For Module Responsibilities
- Scope & Ownership → Hard Constraints → Core Logic → Notes
