#!/usr/bin/env python3
"""
generate_kit.py — Renders all Execution Kit templates from a state JSON and packages into ZIP.

Usage:
    python3 generate_kit.py <state_json_path> <output_zip_path>

The state JSON must have a "fields" object keyed by field_id → { "value": ..., "origin": ... }

Templates are read from the templates/ directory (sibling to scripts/).
This script has ZERO external dependencies — Python stdlib only.
"""

import json
import sys
import os
import re
import zipfile
from pathlib import Path


# ---------------------------------------------------------------------------
# Template engine
# ---------------------------------------------------------------------------

def render_template(template_str: str, context: dict) -> str:
    """Simple {{ variable }} replacement. No loops, no conditionals (by design)."""
    def replacer(match):
        key = match.group(1).strip()
        val = context.get(key, "")
        if val is None:
            return ""
        return str(val)
    return re.sub(r"\{\{\s*(\w+)\s*\}\}", replacer, template_str)


def load_template(templates_dir: Path, filename: str) -> str:
    """Read a .tpl file from the templates directory."""
    path = templates_dir / filename
    if not path.exists():
        print(f"ERROR: Template not found: {path}", file=sys.stderr)
        sys.exit(1)
    return path.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def flatten_state(fields: dict) -> dict:
    """Extract flat key→value dict from the state.fields structure."""
    flat = {}
    for field_id, field_data in fields.items():
        val = field_data.get("value", "")
        if isinstance(val, list):
            if val:
                val = "\n- " + "\n- ".join(str(v) for v in val)
            else:
                val = ""
        elif isinstance(val, bool):
            val = "true" if val else "false"
        elif val is None:
            val = ""
        flat[field_id] = val
    return flat


def build_application_scope(flat: dict) -> str:
    """Merge all pages_* fields into a single application_scope string."""
    scope_parts = []
    page_groups = [
        ("Foundation Pages", "pages_foundation"),
        ("Auth & Profile", "pages_auth"),
        ("Monetization", "pages_payment"),
        ("Core Application", "pages_core"),
    ]
    for label, key in page_groups:
        val = flat.get(key, "").strip()
        if val:
            scope_parts.append(f"**{label}:**\n{val}")
    return "\n\n".join(scope_parts) if scope_parts else "(Not specified)"


def generate_env_example(api_keys_req: str) -> str:
    """Parse the api_keys_req text and generate .env.example content."""
    lines = ["# Environment Variables - Fill in your API keys", ""]
    if not api_keys_req or not api_keys_req.strip():
        lines.append("# No external services specified")
        return "\n".join(lines)

    # Guard: detect "no keys needed" style answers
    lower = api_keys_req.strip().lower()
    no_keys_signals = ["none", "no ", "zero", "n/a", "not applicable", "requires zero"]
    if any(lower.startswith(s) for s in no_keys_signals) or "requires zero" in lower:
        lines.append("# No external services required")
        return "\n".join(lines)

    for line in api_keys_req.strip().split("\n"):
        line = line.strip().lstrip("-").strip()
        if not line:
            continue
        # Extract key name from patterns like "OpenAI API (LLM)"
        name = line.split("(")[0].strip()
        env_key = re.sub(r"[^A-Za-z0-9]+", "_", name).upper().strip("_")
        # Remove trailing _API to avoid duplication (e.g., "OpenAI API" → "OPENAI_API" + "_API_KEY" = double)
        env_key = re.sub(r"_API$", "", env_key)
        if not env_key.endswith("_KEY") and not env_key.endswith("_SECRET"):
            env_key += "_API_KEY"
        lines.append(f"{env_key}=")

    return "\n".join(lines)


def is_cursor_platform(flat: dict) -> bool:
    """Check if the user selected Cursor as their target platform."""
    return "cursor" in flat.get("agent_platform", "").lower()


# ---------------------------------------------------------------------------
# Output validation (Bug #3 fix: smart {{ }} detection)
# ---------------------------------------------------------------------------

# Known field_ids from sections_config.json — only {{ word }} where
# 'word' matches one of these is a REAL unresolved variable.
# Everything else (e.g., {{ variable }} in user-authored documentation
# about templates) is a false positive and gets ignored.
KNOWN_FIELD_IDS = {
    "project_name", "project_type", "target_audience", "project_description",
    "value_proposition", "timeline", "user_type", "success_criteria",
    "user_personas", "pages_foundation", "pages_auth", "pages_payment",
    "pages_core", "out_of_scope", "features_list", "workflow_logic",
    "business_rules", "glossary", "acceptance_criteria", "edge_cases",
    "design_tone", "design_dna", "design_primary_color", "design_references",
    "design_wireframe_desc", "tech_stack_fe", "tech_stack_be", "tech_stack_db",
    "data_schema", "tech_constraints", "api_keys_req", "nfr_security",
    "agent_platform", "agent_team", "coding_standards", "custom_agent_rules",
    "agent_tool_policy", "application_scope",
}


def validate_output(files_to_zip: dict) -> list:
    """
    Check for REAL unresolved template variables in output files.

    Returns a list of (filename, variable) tuples for genuinely unresolved vars.
    Ignores {{ }} patterns where the inner word is NOT a known field_id —
    those are user-authored content (documentation, coding standards, etc.).
    """
    issues = []
    for fname, content in files_to_zip.items():
        matches = re.findall(r"\{\{\s*(\w+)\s*\}\}", content)
        for var_name in matches:
            if var_name in KNOWN_FIELD_IDS:
                issues.append((fname, var_name))
    return issues


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 generate_kit.py <state_json_path> <output_zip_path>")
        sys.exit(1)

    state_path = sys.argv[1]
    output_path = sys.argv[2]

    # Resolve templates directory (sibling to scripts/)
    script_dir = Path(__file__).resolve().parent
    templates_dir = script_dir.parent / "templates"
    if not templates_dir.exists():
        print(f"ERROR: Templates directory not found: {templates_dir}", file=sys.stderr)
        sys.exit(1)

    # Load state
    with open(state_path, "r") as f:
        state = json.load(f)

    fields = state.get("fields", {})
    flat = flatten_state(fields)

    # Build computed fields
    flat["application_scope"] = build_application_scope(flat)

    # Determine platform
    is_cursor = is_cursor_platform(flat)

    # Determine active agents
    agent_team_raw = flat.get("agent_team", "")

    # ---------------------------------------------------------------------------
    # Render all templates from .tpl files
    # ---------------------------------------------------------------------------
    files_to_zip = {}

    # Core docs (always included)
    files_to_zip["PRD_Master.md"] = render_template(
        load_template(templates_dir, "PRD_Master.md.tpl"), flat
    )
    files_to_zip["PRD_Plan.md"] = render_template(
        load_template(templates_dir, "PRD_Plan.md.tpl"), flat
    )

    # Readme: conditional on platform (Bug #2 fix)
    if is_cursor:
        files_to_zip["readme.md"] = render_template(
            load_template(templates_dir, "readme_cursor.md.tpl"), flat
        )
    else:
        files_to_zip["readme.md"] = render_template(
            load_template(templates_dir, "readme_generic.md.tpl"), flat
        )

    # Agent files (include all by default unless user explicitly excluded)
    if "architect" in agent_team_raw.lower() or not agent_team_raw.strip():
        files_to_zip["agent_architect.md"] = render_template(
            load_template(templates_dir, "agent_architect.md.tpl"), flat
        )
    if "builder" in agent_team_raw.lower() or not agent_team_raw.strip():
        files_to_zip["agent_builder.md"] = render_template(
            load_template(templates_dir, "agent_builder.md.tpl"), flat
        )
    if "reviewer" in agent_team_raw.lower() or not agent_team_raw.strip():
        files_to_zip["agent_reviewer.md"] = render_template(
            load_template(templates_dir, "agent_reviewer.md.tpl"), flat
        )

    # Platform config
    if is_cursor:
        files_to_zip[".cursorrules"] = render_template(
            load_template(templates_dir, "cursorrules.tpl"), flat
        )
    files_to_zip["platform_generic.md"] = render_template(
        load_template(templates_dir, "platform_generic.md.tpl"), flat
    )

    # .env.example (dynamically generated, no template file needed)
    files_to_zip[".env.example"] = generate_env_example(flat.get("api_keys_req", ""))

    # ---------------------------------------------------------------------------
    # Validate output (Bug #3 fix: only flag known field_ids)
    # ---------------------------------------------------------------------------
    issues = validate_output(files_to_zip)
    if issues:
        print("⚠️  UNRESOLVED TEMPLATE VARIABLES (real field_ids not rendered):", file=sys.stderr)
        for fname, var_name in issues:
            print(f"   {fname}: {{{{ {var_name} }}}}", file=sys.stderr)
        # Warning only — don't block generation (user may have left optional fields empty)

    # Collision guard
    filenames = list(files_to_zip.keys())
    if len(filenames) != len(set(filenames)):
        print("ERROR: Duplicate filenames detected in output!", file=sys.stderr)
        sys.exit(1)

    # Write ZIP
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, content in files_to_zip.items():
            zf.writestr(fname, content)

    print(f"✅ Execution Kit generated: {output_path}")
    print(f"   Files: {len(files_to_zip)}")
    for fname in sorted(files_to_zip.keys()):
        print(f"   - {fname}")


if __name__ == "__main__":
    main()
