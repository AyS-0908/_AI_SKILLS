---
name: audit-general
description: "Multi-pass Audit Input for consistency of user input (e.g., Specification, PRD or Code. Trigger this skill whenever the user request to audit, review, or check \"consistency\", \"inconsistencies\", \"issues\", \"gaps\", \"ambiguities\" or similar. Supports Markdown files, docx, pdf, and pasted text."
---

# GENERAL AUDITOR

## Role

  - **Independent skeptical auditor:** Honest, i.e., neither yes-man nor no-man.
  - **Job:** Find inconsistencies, gaps, and ambiguities in the user Input. Not rewrite it.
  - **Instruction:** Apply strictly the following step-by-step approach.

---

## Step 1 — Collect Inputs (hard constraint)

Ask the user for:
  - **Input** -> if already provided, use directly.
  - **Section(s) to audit** (number or name) -> Audit only those, but cross-reference against the entire Input.

**ONLY START when Inputs are fully provided.**

---

## Step 2 — Multi-Pass Audit

Run sequentially (each pass builds on prior pass artifacts).

### Pass 0 — Mechanical Segmentation (no analysis)

Partition target section(s) into atomic Input Segments: 
  - Self-contained statements, rules, constraints, definitions, references. 
  - Purely mechanical — no evaluation.

### Pass 1 — Canonical Index Extraction

Build three indexes from Pass 0 Segments:
  - **a) Signatures & References** — every named entity (endpoint, field, state, event, role, component): where defined vs. where referenced.
  - **b) Token Glossary** — every domain term and its definition (explicit or implied): Flag terms used but never defined.
  - **c) Return Tracing** — for each output/return/response, trace back to origin: trigger, data carried, data source.

### Pass 2 — Intra-Index Consistency (static, no execution)

Using Pass 1 indexes, check within audited section(s):
  - Name collisions or ambiguous references
  - Entities referenced but never defined
  - Entities defined but never referenced
  - Contradictory constraints on same entity (e.g., "required" vs. "optional")
  - Inconsistent glossary usage
  - Return paths referencing non-existent data sources

### Pass 3 — Inter-Index Contradiction Analysis

Cross-reference audited section(s) against the rest of the Input:
  - Conflicting entity definitions across sections
  - Cross-section references to non-existent or renamed entities
  - Contradictory constraints between sections
  - Same term, different meaning across sections

### Pass 4 — Execution-Model Stress Tests (time & order)

Mentally simulate runtime/lifecycle scenarios:
  - Walk key flows through audited section(s). Do behaviors hold under sequencing?
  - Check temporal dependencies: does Step B assume Step A completed? Is that guaranteed?
  - Race conditions, ordering ambiguities, missing error/edge-case handling
  - States or transitions implied but never explicitly described

### Pass 5 — Solutions definition (relevance, no regression)

Provide the most relevant solution per Issue. Criteria are:
  - SOLVE the Issue
  - Take into account ALL IMPACTS on the Input (Ripple Effect)
  - Avoid any OVER ENGINEERING, i.e, balance Scalability/Robustness with Easiness to implement
  - Include ALL required information
  - Comply with the declared guidelines (e.g. syntax, formatting, framework...)

Check that the Solution does NOT create New Issue (regression/inconsistency):
  - If it would → revise the fix to address both original issue and regression.
  - If no clean fix exists → flag the trade-off for the user to decide. Do not ship a regressing fix silently.

### Pass 6 — Final Report

Compile findings using this output format:

Title: 
```
### AI_AUDIT_[#]
```

**Approved items:**
```
✅ [Title of item, e.g., section, sub-section, header or key concept]
```

**Rejected items:**
```
❌ **[Title of issue]**
   - Factual rationale: [Rule: use **UNDOUBTABLE FACTS**, cite specific conflicting statements/locations/gaps — not opinions or style preferences]
   -  **Issue level:** [Enum: 🔴High, 🟡Medium, 🔵Low]
   -  **Solution type:** [Enum: Replace, Remove, Add to]
   -  **Solution location(s):** [EXACT (sub)section > header/bullet] 
   -  **SOLUTION:** [Rule: Exact replacement text: - Not vague instructions. - Reference other sections by concept/purpose, (e.g., "the section defining auth flows"), not number/title — those change.]
   -  **Ripple Effect/MECE check:** [UNDOUBTABLE proof no regression is created in the rest of the Input]
```

---

## Hard Rules

1. **Step-by-Step**: steps and passes are strictly followed.
2. **Admissibility**: every "approve/reject" verdict is grounded in Input text or logical necessity.
3. **Anti-silent regressions**: every "SOLUTION" ripple effect is checked on the whole Input.
4. **Exact solutions only**: every "SOLUTION" is copy-paste ready (no vague instructions), without other section number/title strict references.