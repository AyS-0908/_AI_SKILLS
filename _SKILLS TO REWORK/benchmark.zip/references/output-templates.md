# Output Templates

## Route
- 2+ entities → Template A (Matrix)
- 1 entity vs market OR user requests narrative → Template B

---

## Template A — Matrix

```
## [Benchmark Title]
Scope: [Entities] · [Purpose] · [Depth] · [Date]

### Comparison Matrix

| Criterion | [Entity 1] | [Entity 2] |
|---|---|---|
| [criterion] | [value · source] | [value · source] |

### Key Findings
1. [top differentiator — decision-relevant]
2. [secondary differentiator]
IF Depth=Deep: up to 5 / IF Standard: 3 / IF Directional: 2

### Recommendations
[Recommended choice] for [profile/context]. [1-2 sentence rationale anchored in findings.]
IF condition for alternative exists: [Alternative] if [specific condition].

### Data Quality
IF any: [DATA GAP] / conflicting sources / data >6mo → list here
ELSE: omit section entirely

### Benchmark Limits
Excludes: [adjacent scope items user might expect]
```

### Cell rules
- Format: value · source
- Missing data → `[DATA GAP]` — never estimate
- Incompatible basis → `[NOT COMPARABLE]`
- No scoring column unless user requested

---

## Template B — Narrative

```
## [Title] — Positioning Analysis
Scope: [Entity] vs [market refs] · [Purpose] · [Depth] · [Date]

### Context
[2 sentences: why this entity, which refs, comparison logic]

### Analysis
**[Main entity]** — positioning, strengths, weaknesses. Data-anchored.
**[Ref 1]** / **[Ref 2]** — calibration only, shorter.

### Cross-cutting Findings
[What emerges across entities — structural arbitrage, shared risk, market dynamic]

### Recommendations
[Same rules as Template A]

### Data Quality & Limits
[Same rules as Template A]
```
