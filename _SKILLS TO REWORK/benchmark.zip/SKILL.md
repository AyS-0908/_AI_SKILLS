---
name: benchmark
description: >
  Structured competitive benchmark. Collects, normalizes, and compares
  multiple entities across user-defined or domain-specific criteria.
  Produces evidence-backed comparison matrices and synthesis.
  Trigger for: "benchmark", "compare competitors", "competitive analysis",
  "how does X compare to Y", "market comparison", "pricing comparison",
  "feature comparison", "competitive landscape", "compare X vs Y vs Z",
  any request to systematically compare two or more external entities.
  Do NOT trigger for: internal audits, consistency checks, document reviews,
  single-artifact analysis, SWOT of a single entity without competitors,
  general strategic analysis without explicit comparison intent,
  "what's the best X" without structured comparison request.
---

# Benchmark Skill

Structured competitive analysis using web search to collect real data.
Five phases: scope → criteria → collect → compare → synthesize.

**This skill MUST use web search to collect data.** Do not rely on training knowledge for factual claims about entities (pricing, features, market position). Search for current information.

---

## Gotchas

- **Web search returns nothing useful** → flag `[DATA GAP]`, never infer or fabricate
- **Conflicting sources** → show both with source labels, never silently pick one
- **Paywalled sources** → try press release / exec summary / public blog. IF nothing → `[DATA GAP]`
- **User uploads** → confirm before incorporating, label `[USER-PROVIDED]`

---

## Phase 1 — SCOPE AND INTAKE

**Input:** User request
**Output:** Locked scope (entities, purpose, depth, criteria, output format)

### Detect Depth Mode

- "quick look", "rough comparison", "directional" → `Directional`
- Default / no signal → `Standard`
- "thorough", "deep dive", "comprehensive", "board-level" → `Deep`

### Extract What's Already in the Request

Parse the user prompt first. Extract any entities, purpose, criteria, and depth signals already provided. Only ask what's genuinely missing.

### Blocking Questions (only if missing — ask together, stop until answered)

1. **Entities** — IF not identifiable from request: "Who/what should we compare?" (minimum 2 for matrix, 1 for deep-dive)
2. **Purpose** — IF not identifiable AND depth is not `Directional`: "What's the comparison purpose?" (purchase decision / strategic positioning / feature gap / pricing / other)

- IF depth is `Directional` AND purpose not stated → [Assumed: inferred from entities + domain]
- IF all blocking info is already in the request → skip questions, go straight to scope summary

### Single-Entity Mode

- IF only 1 entity + "vs the market" / "vs competitors" / "vs alternatives" → single-entity deep-dive
- Identify 2–3 relevant market reference points for comparison
- Default output: narrative format (not matrix)

### Non-Blocking (assume if not answered, state assumption)

- Criteria: [Assumed: inferred from purpose + domain]
- Depth: [Assumed: Standard]
- Output format: [Assumed: matrix — except single-entity → narrative]
- Evidence perimeter: [Assumed: open web sources]

→ Present scope summary to user. Proceed on confirmation.

---

## Phase 2 — CRITERIA DEFINITION

**Input:** Locked scope from Phase 1
**Output:** Confirmed criteria list

### Criteria Source Selection (in priority order)

1. IF user already specified criteria → use them directly. Confirm and adjust if needed.
2. ELSE IF `references/criteria-{domain}.md` exists and matches → load, confirm with user
3. ELSE → infer from purpose:

| Purpose | Default Criteria |
|---|---|
| Purchase decision | Price, features, support quality, maturity, lock-in risk |
| Strategic positioning | Market position, differentiation, momentum, reach |
| Feature gap | Feature-by-feature checklist |
| Pricing | Plans, pricing model, unit economics, hidden costs, TCO |
| Strategic inspiration | Market position, disruption nature, revenue impact, strategic response, new revenue streams, AI usage, current trajectory, transferable lesson |

### Criteria Limits

| Depth | Max Criteria |
|---|---|
| Directional | 6 |
| Standard | 10 |
| Deep | 15 |

**Principle:** Fewer focused criteria > many shallow ones. Cut a criterion rather than fill it with non-comparable data.

→ Present criteria list to user before proceeding to data collection.

---

## Phase 3 — DATA COLLECTION

**Input:** Confirmed entities + criteria
**Output:** Data matrix with evidence

**USE WEB SEARCH for every entity × criterion.** Do not fill cells from training knowledge. Search for current, verifiable information.

### How to Search

- For each entity, search its official website, pricing page, and documentation first
- Then broaden to aggregators (G2, Capterra), analyst reports, press coverage
- For each data point found, note the source and how recent it is
- IF user provided internal data → label `[USER-PROVIDED]`, slot alongside official sources

### What to Record Per Cell

Scales with depth mode:

| Depth | What goes in each cell |
|---|---|
| Directional | Value + source name. That's it. |
| Standard | Value + source name + date. Flag `[DATA GAP]` or `[ESTIMATED]` where needed. |
| Deep | Value + source + date + quality tag (`EXACT`/`ESTIMATED`/`DIRECTIONAL`) + confidence (`HIGH`/`MED`/`LOW`). Flag aging data (>6 months). |

### When Data Is Missing

1. Try broader search terms
2. IF paywalled → try press release / exec summary / blog
3. IF nothing → `[DATA GAP]` — do NOT infer, estimate, or fill from training knowledge

### Normalization (check before moving to Phase 4)

- **Units:** consistent across all entities (same currency, same billing period, same unit)
- **Vocabulary:** align equivalent tier names ("Enterprise" ≈ "Business Plus")
- **Comparability:** same geography, segment, and tier. IF not achievable → flag it

For `Deep` mode, also check:
- List price vs. transacted/negotiated price — don't mix
- Self-reported metrics vs. independently verified — label which is which
- Review sentiment ≠ representative market truth

---

## Phase 4 — COMPARISON AND ANALYSIS

**Input:** Data matrix from Phase 3
**Output:** Comparison matrix with analysis

### Build Comparison Matrix

- Rows = criteria, columns = entities
- Cell content follows the depth-mode format from Phase 3

### Scoring

- IF user explicitly requested scoring → apply 1–5 scale WITH evidence per score
- IF not → no scores. Evidence and labels are the analysis.
- IF two data points are not on the same basis → `[NOT COMPARABLE]`

---

## Phase 5 — SYNTHESIS AND OUTPUT

**Input:** Comparison matrix from Phase 4
**Output:** Final deliverable

→ **Read `references/output-templates.md` for format details and examples.**

### Matrix Format (default for multi-entity)

1. **Comparison matrix table**
2. **Key findings** — top differentiators + top gaps (count scales with depth: 2 for Directional, 3 for Standard, 5 for Deep)
3. **Data quality statement** — only if there are gaps, aging data, or comparability issues. Skip if clean.
4. **Recommendations** — actionable, tied to findings, framed by comparison purpose
5. **Benchmark limits** — what this benchmark does NOT cover

### Narrative Format (default for single-entity, or if user requests)

1. Context & methodology
2. Per-entity analysis (positioning, strengths, weaknesses)
3. Cross-cutting findings
4. Recommendations
5. Data quality + limits (if relevant)

---

## Core Rules

These apply across all phases. They exist because benchmarks are only useful if the data is trustworthy.

- **Never fabricate.** No data point without a real source. `[DATA GAP]` is always better than a guess.
- **Never silently resolve conflicts.** When sources disagree, show both.
- **Comparability > exhaustiveness.** Cut a criterion rather than fill it with non-comparable data.
- **Say when data is thin.** If there isn't enough to compare meaningfully, say so.
- **Official sources win** for factual claims (pricing, features, specs). Analyst framing is context, not ground truth.
